#!/bin/bash
sudo apt-get clean
sudo rm -rf /var/cache/
sudo rm -rf /tmp
sudo rm -rf /root/.cache/
sudo rm -rf /home/lancaster/.local/share/Trash
sudo rm -rf /root/.local/share/Trash/
